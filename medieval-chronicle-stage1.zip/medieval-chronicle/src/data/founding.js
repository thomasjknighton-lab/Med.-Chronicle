// Founding priority: a fixed historical identity, not a permanent strategy.
export const FOUNDING_IDS = ['food', 'trade', 'cooperation', 'autonomy'];

export const FOUNDING_PRIORITIES = {
  food: {
    id: 'food',
    name: 'Food Security',
    description: 'The founders agree that no one should go hungry if it can be helped. Fields and stores come first.',
    effects: { food: 1 },
    outcome: 'The founders clear and sow a little more land before anything else.'
  },
  trade: {
    id: 'trade',
    name: 'Trade and Opportunity',
    description: 'The founders look outward, to paths, landings, and neighbours who might exchange goods.',
    effects: { wealth: 1 },
    outcome: 'The founders trade early with neighbouring settlements and keep what they earn.'
  },
  cooperation: {
    id: 'cooperation',
    name: 'Community Cooperation',
    description: 'The founders agree to settle disputes together and share heavy work.',
    effects: { stability: 1 },
    outcome: 'The founders agree on ways to settle quarrels before they grow.'
  },
  autonomy: {
    id: 'autonomy',
    name: 'Local Autonomy',
    description: 'The founders want to keep their own customs and bargain firmly with anyone who claims authority over them.',
    effects: {},
    outcome:
      'The founders write nothing down, but everyone remembers the customs they agreed. Those memories give the village a stronger hand when bargaining over obligations.'
  }
};
