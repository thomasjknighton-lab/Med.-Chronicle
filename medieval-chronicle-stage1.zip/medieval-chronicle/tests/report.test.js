import test from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, mkdirSync } from 'node:fs';
import { jsPDF } from 'jspdf';
import { createInitialState, reduce } from '../src/engine/state.js';
import { buildReport, toPdfText, reportFilename } from '../src/export/report.js';

test('PDF builds for a brand-new, empty playthrough', () => {
  const doc = buildReport(jsPDF, createInitialState('test-1234'), { generatedAt: 'test' });
  assert.ok(doc.getNumberOfPages() >= 5);
});

test('PDF builds after Decision 1 with special characters and long names', () => {
  let s = createInitialState('test-1234');
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'CONFIRM_NAMES', names: { village: 'Þorsbyrig-on-Æsc River', farmer: 'Ælfflæd', craft: 'Nguyễn Thị Ánh', priest: 'Wulfgar' }, geography: 'river' });
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'SELECT', key: 'founding', option: 'food' });
  s = reduce(s, { type: 'CONFIRM_FOUNDING' });
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'SELECT', key: 'd1', option: 'A' });
  s = reduce(s, { type: 'CONFIRM_DECISION' });
  s = reduce(s, { type: 'SET_DRAFT', field: 'arg.claim', value: 'The biggest change was… '.repeat(80) });
  assert.equal(s.stage, 'outcome');
  const doc = buildReport(jsPDF, s, { studentName: 'Test Student', generatedAt: 'November 11, 2026' });
  mkdirSync('tests/output', { recursive: true });
  writeFileSync('tests/output/sample-report.pdf', Buffer.from(doc.output('arraybuffer')));
  assert.ok(doc.getNumberOfPages() >= 5);
  assert.equal(reportFilename(s), 'village-history-report-thorsbyrig-on-aesc-river.pdf');
});

test('toPdfText keeps Old English letters and simplifies others', () => {
  assert.equal(toPdfText('Ælfflæd Þ ð'), 'Ælfflæd Þ ð');
  assert.equal(toPdfText('Nguyễn'), 'Nguyen');
  assert.equal(toPdfText('名'), '?');
});
