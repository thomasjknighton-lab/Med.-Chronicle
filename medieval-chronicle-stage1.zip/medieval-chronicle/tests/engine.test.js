import test from 'node:test';
import assert from 'node:assert/strict';
import { GEOGRAPHIES, GEOGRAPHY_IDS } from '../src/data/geographies.js';
import { FOUNDING_IDS, FOUNDING_PRIORITIES } from '../src/data/founding.js';
import { DECISIONS } from '../src/data/decisions.js';
import { validateName } from '../src/data/names.js';
import { applyEffects, RESOURCE_KEYS } from '../src/engine/resources.js';
import { createInitialState, reduce } from '../src/engine/state.js';
import { choicesFromState, rebuild } from '../src/engine/rebuild.js';
import { makeBackup, parseBackup, checksum } from '../src/engine/backup.js';

const NAMES = { village: 'Æscford', farmer: 'Eadgifu', craft: 'Osgar', priest: 'Wulfgar' };

function play(geography, founding, d1) {
  let s = createInitialState('test-1234');
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'CONFIRM_NAMES', names: NAMES, geography });
  if (!founding) return s;
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'SELECT', key: 'founding', option: founding });
  s = reduce(s, { type: 'CONFIRM_FOUNDING' });
  if (!d1) return s;
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'SELECT', key: 'd1', option: d1 });
  s = reduce(s, { type: 'CONFIRM_DECISION' });
  return s;
}

test('every geography starts with resources summing to 12', () => {
  for (const id of GEOGRAPHY_IDS) {
    const sum = RESOURCE_KEYS.reduce((a, k) => a + GEOGRAPHIES[id].start[k], 0);
    assert.equal(sum, 12, id);
  }
});

test('every decision has exactly four options', () => {
  for (const d of DECISIONS) assert.equal(d.options.length, 4, d.id);
});

test('clamping records requested vs applied change', () => {
  const { after, changes } = applyEffects({ food: 5, population: 1, wealth: 3, stability: 3 }, { food: 1, population: -2, wealth: 1 });
  assert.deepEqual(after, { food: 5, population: 1, wealth: 4, stability: 3 });
  const food = changes.find((c) => c.key === 'food');
  assert.equal(food.applied, 0);
  assert.equal(food.capped, true);
  assert.equal(changes.find((c) => c.key === 'wealth').capped, false);
});

test('all geographies x founding priorities x Decision 1 options produce expected resources', () => {
  for (const g of GEOGRAPHY_IDS) for (const f of FOUNDING_IDS) for (const opt of DECISIONS[0].options) {
    const s = play(g, f, opt.id);
    const expected = { ...GEOGRAPHIES[g].start };
    for (const eff of [FOUNDING_PRIORITIES[f].effects, opt.effects]) {
      for (const [k, v] of Object.entries(eff)) expected[k] = Math.min(5, Math.max(1, expected[k] + v));
    }
    assert.deepEqual(s.resources, expected, `${g}/${f}/${opt.id}`);
    assert.equal(s.stage, 'outcome');
    assert.equal(s.decisions.d1.option, opt.id);
    for (const flag of opt.flags) assert.ok(s.flags.includes(flag));
  }
});

test('Decision 1 option C (customary obligations) adds no resource change but a landholder note', () => {
  const s = play('river', 'food', 'C');
  const entry = s.resourceHistory.find((r) => r.id === 'd1');
  assert.equal(entry.changes.length, 0);
  assert.equal(s.relationships.landholder.length, 1);
});

test('reducer does not mutate its input', () => {
  const s = play('coastal', 'trade', null);
  const frozen = JSON.stringify(s);
  reduce(s, { type: 'SELECT', key: 'founding', option: 'food' });
  assert.equal(JSON.stringify(s), frozen);
});

test('confirming twice never double-applies effects', () => {
  const s = play('woodland', 'cooperation', 'B');
  const again = reduce(s, { type: 'CONFIRM_DECISION' });
  assert.equal(again, s);
  const refounding = reduce(s, { type: 'CONFIRM_FOUNDING' });
  assert.equal(refounding, s);
});

test('a confirmed choice cannot be changed', () => {
  let s = play('upland', 'autonomy', 'A');
  s = reduce(s, { type: 'ADVANCE' });
  const changed = reduce(s, { type: 'SELECT', key: 'd1', option: 'D' });
  assert.equal(changed, s);
});

test('selection can change before confirmation', () => {
  let s = play('river', 'food', null);
  s = reduce(s, { type: 'ADVANCE' });
  s = reduce(s, { type: 'SELECT', key: 'd1', option: 'A' });
  s = reduce(s, { type: 'SELECT', key: 'd1', option: 'B' });
  assert.equal(s.pending.d1, 'B');
});

test('geography is never reassigned once set', () => {
  const s = play('river', null, null);
  assert.equal(s.geography, 'river');
  const again = reduce(s, { type: 'CONFIRM_NAMES', names: NAMES, geography: 'upland' });
  assert.equal(again, s);
});

test('invalid names are rejected', () => {
  assert.ok(validateName(''));
  assert.ok(validateName('   '));
  assert.ok(validateName('<img src=x onerror=alert(1)>'));
  assert.ok(validateName('a'.repeat(31)));
  assert.equal(validateName('Ælfflæd'), null);
  assert.equal(validateName("Mary-Ann O'Neil"), null);
  let s = reduce(createInitialState('test-1234'), { type: 'ADVANCE' });
  assert.equal(reduce(s, { type: 'CONFIRM_NAMES', names: { ...NAMES, farmer: '<b>' }, geography: 'river' }), s);
});

test('rebuilding from saved choices reproduces the same state at every stage', () => {
  let s = createInitialState('test-1234');
  const actions = [
    { type: 'ADVANCE' },
    { type: 'SET_DRAFT', field: 'village', value: 'Æsc' },
    { type: 'CONFIRM_NAMES', names: NAMES, geography: 'coastal' },
    { type: 'ADVANCE' },
    { type: 'SELECT', key: 'founding', option: 'trade' },
    { type: 'CONFIRM_FOUNDING' },
    { type: 'ADVANCE' },
    { type: 'SELECT', key: 'd1', option: 'C' },
    { type: 'CONFIRM_DECISION' },
    { type: 'ADVANCE' }
  ];
  for (const a of actions) {
    s = reduce(s, a);
    assert.deepEqual(rebuild(choicesFromState(s)), s, `after ${a.type}`);
  }
});

test('backup round trip works; tampered, malformed, or foreign files are rejected', () => {
  const s = play('upland', 'cooperation', 'D');
  const text = JSON.stringify(makeBackup(s, '2026-11-11'));
  const ok = parseBackup(text);
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.state, s);

  const tampered = JSON.parse(text);
  tampered.data.decisions.d1 = 'A';
  assert.equal(parseBackup(JSON.stringify(tampered)).ok, false);

  assert.equal(parseBackup('{not json').ok, false);
  assert.equal(parseBackup(JSON.stringify({ app: 'other' })).ok, false);

  // Valid checksum but impossible content (decision before founding)
  const bad = makeBackup(play('river', null, null));
  bad.data.decisions = { d1: 'A' };
  bad.checksum = checksum(JSON.stringify(bad.data));
  assert.equal(parseBackup(JSON.stringify(bad)).ok, false);
});

