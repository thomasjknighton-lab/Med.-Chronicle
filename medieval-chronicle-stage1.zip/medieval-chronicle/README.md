# The Medieval Chronicle

A browser-based simulation for 10th-grade World History. Students guide a fictional English village from about 920 to 1381, read four real historical sources, write a historical argument, and download a PDF report to submit in Canvas.

**Current build: Stage 1 (vertical slice).** Setup, random geography, founding priority, Decision 1, outcome screen, resources, village map, Chronicle, autosave, backup/import, and PDF export all work. Decisions 2–9, the sources, reflections, epilogue, and final argument arrive in Stages 2–4.

No login, database, server, API keys, or tracking. Student work stays in the browser until the student downloads the PDF.

## Test it on your computer

The site uses JavaScript modules, which browsers block when you double-click `index.html`. Run a tiny local web server instead.

1. Open a terminal in this folder.
2. Run `python3 -m http.server 8000` (on Windows: `py -m http.server 8000`).
3. Visit http://localhost:8000 in Chrome.

To start a fresh village while testing, open an **Incognito window** (Ctrl+Shift+N). There is deliberately no "start over" button, so students cannot reroll their geography.

### Automated tests (optional)

Requires Node.js 18+.

```
npm install
npm test
```

Tests cover resource clamping, every geography × founding priority × Decision 1 option, protection against double-applied effects, rebuilding saved progress, backup tampering, and PDF generation with special characters.

## Publish on GitHub Pages

1. Create a **public** repository on GitHub (for example `medieval-chronicle`).
2. Upload everything in this folder (Add file → Upload files). You do not need `node_modules`, `tests`, or `package.json` for the live site, but including them is harmless.
3. In the repository, go to **Settings → Pages**. Under "Build and deployment," choose **Deploy from a branch**, branch `main`, folder `/ (root)`. Save.
4. After a minute or two, the site is live at `https://YOUR-USERNAME.github.io/medieval-chronicle/`.

All paths are relative, so the site works inside a repository subfolder.

## Link it from Canvas

Add the GitHub Pages URL as an External URL module item or a link in an assignment. Create a separate Canvas assignment with **File Upload** submission (PDF) for the Village History Report.

**Before class:** test on a student Chromebook while signed in as a student. District settings can block downloads, local storage, or specific sites. Confirm that (1) progress survives a page reload, and (2) the PDF downloads and can be uploaded to Canvas.

## How student data is saved

- Progress saves automatically to the browser's local storage on that Chromebook. Typing saves within half a second and immediately when the tab is hidden or closed.
- Clearing browsing data, using Guest mode, or switching devices loses progress. Students can download a **backup file** (Backup menu) and load it later on any device.
- Backups contain only choices and student-written text. On load, the app checks the file and rebuilds everything else from scratch, so an edited or damaged backup is refused rather than trusted.
- The student's name for the PDF is typed at download time and is never saved.

## Editing text safely

All student-facing text lives in `src/data/`:

| File | Contains |
|---|---|
| `text.js` | Intro, privacy notice, resource definitions, chapter titles |
| `geographies.js` | The four geographies and starting resources |
| `founding.js` | Founding priorities |
| `names.js` | Name suggestions and the blocked-word list |
| `decisions.js` | Decisions, options, previews, and outcomes |

Edit only the text inside quotes. Keep `{village}`, `{farmer}`, `{craft}`, and `{priest}` exactly as written; they are replaced with the student's names. If you change a resource effect, run `npm test` afterward. Starting resources must still total 12.

## File structure

```
index.html              Page shell
styles/main.css         All styling
src/main.js             App shell, menu, dialogs, autosave
src/data/               Student-facing content (edit here)
src/engine/             Pure logic: state, resources, rebuild, backup, map model, progress
src/ui/                 Screens, map drawing, DOM helpers, browser storage
src/export/report.js    PDF report builder
vendor/jspdf/           jsPDF 2.5.2, bundled locally (MIT licence)
tests/                  Automated engine and PDF tests
docs/                   QA checklist and source-verification status
```

## Licences and attribution

- jsPDF 2.5.2, MIT licence: `vendor/jspdf/LICENSE.txt`.
- All map artwork is drawn in code for this project.
- Historical source excerpts (Stage 3) will be cited in `docs/SOURCES.md` with translator, edition, and URL.
