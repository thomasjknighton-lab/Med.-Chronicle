// Map state is DERIVED from confirmed choices and flags, never stored, so it is always reproducible.
import { fill } from './state.js';

const FIELD_TEXT = {
  river: 'Long strips of ploughed land run down toward the river meadows, where hay is cut each summer.',
  coastal: 'Strips of barley and oats run inland from the shore. Seaweed is spread on them to enrich the soil.',
  woodland: 'Small fields have been cut out of the trees. Stumps still stand at their edges.',
  upland: 'A few sheltered strips grow oats. Most land is rough grazing for sheep and cattle.'
};
const WORKSHOP_TEXT = {
  river: '{craft} works here, making pots and mending iron tools brought up and down the river.',
  coastal: '{craft} works here, mending nets and boiling seawater in the salt pans.',
  woodland: '{craft} works here, shaping timber into tools, bowls, and fence posts.',
  upland: '{craft} works here, combing wool and making leather goods.'
};
const NATURE = {
  river: { name: 'The river', text: 'The river brings fish, rich meadows, travellers, and sometimes floods.' },
  coastal: { name: 'The shore', text: 'Boats, nets, and salt pans line the shore. Storms can wreck them in a night.' },
  woodland: { name: 'The wood', text: 'The wood gives timber, firewood, and acorns for pigs. Who may use it is a serious matter.' },
  upland: { name: 'The fell', text: 'Open moorland where sheep and cattle graze in summer, shared by several families.' }
};

export function deriveMap(state) {
  const g = state.geography;
  if (!g) return null;
  const f = new Set(state.flags);
  const N = state.names;
  const t = (x) => fill(x, N);
  const places = [
    { id: 'fields', name: 'Fields', text: FIELD_TEXT[g] },
    {
      id: 'homes',
      name: 'Homes',
      text: t('Timber houses with thatched roofs. {farmer}’s family lives at the end nearest the fields.') +
        (f.has('upkeep_precedent') ? ' The roofs were freshly thatched before winter.' : ''),
      changed: f.has('upkeep_precedent')
    },
    { id: 'church', name: 'Church', text: t('A small timber church served by {priest}. Villagers gather here for worship, news, and festivals.') },
    { id: 'workshop', name: 'Workshop', text: t(WORKSHOP_TEXT[g]) },
    {
      id: 'road',
      name: 'Road to the hall',
      text: 'A track leads to the landholder’s hall and to neighbouring settlements.' +
        (f.has('dependable_landholder') ? ' Carts carrying the food render have worn deep ruts in it.' : ''),
      changed: f.has('dependable_landholder')
    },
    { id: 'nature', name: NATURE[g].name, text: NATURE[g].text }
  ];
  if (f.has('shared_reserves')) places.push({ id: 'store', name: 'Shared store', text: 'The shared grain store. Everyone remembers who added what.', isNew: true });
  if (f.has('cooperative_precedent')) places.push({ id: 'threshing', name: 'Threshing floor', text: 'A shared floor where families beat grain together.', isNew: true });
  return { geography: g, flags: f, places };
}
