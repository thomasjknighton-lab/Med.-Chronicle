import { DECISIONS, TOTAL_DECISIONS, getDecision } from '../data/decisions.js';
import { ERAS } from '../data/text.js';

export function decisionsConfirmed(state) {
  return Object.keys(state.decisions).length;
}

/** Completion summary used on screen and in the PDF. Items not built yet count as not completed. */
export function completionSummary(state) {
  const d = state.drafts;
  const filled = (k) => typeof d[k] === 'string' && d[k].trim().length > 0;
  const items = [
    { label: 'Village founded', done: state.founding ? 1 : 0, total: 1 },
    { label: 'Decisions', done: decisionsConfirmed(state), total: TOTAL_DECISIONS },
    { label: 'Source observations', done: 0, total: 4 },
    { label: 'Era reflections', done: 0, total: 3 },
    { label: 'Decision justifications', done: 0, total: 2 },
    { label: 'Historical argument', done: ['arg.claim', 'arg.evidence', 'arg.explanation'].filter(filled).length, total: 3 }
  ];
  const complete = items.every((i) => i.done >= i.total);
  return { items, complete };
}

export function progressLabel(state) {
  const d = state.currentDecision ? getDecision(state.currentDecision) : null;
  if (state.stage === 'sliceEnd') return { era: ERAS.early, year: 'c. 920', text: `${decisionsConfirmed(state)} of ${TOTAL_DECISIONS} decisions made` };
  if (d) return { era: ERAS[d.era], year: d.year, text: `Decision ${d.number} of ${TOTAL_DECISIONS}` };
  if (['geography', 'founding', 'founded'].includes(state.stage)) return { era: ERAS.early, year: 'c. 920', text: 'Founding the village' };
  return { era: null, year: '', text: 'Getting started' };
}

export { DECISIONS };
