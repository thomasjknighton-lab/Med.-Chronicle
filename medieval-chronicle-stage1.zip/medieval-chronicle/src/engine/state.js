// Single source of truth. reduce() is pure: it never mutates its input, never uses randomness
// or the clock, and returns the SAME object when an action is not allowed (a no-op).
import { GEOGRAPHIES } from '../data/geographies.js';
import { FOUNDING_PRIORITIES } from '../data/founding.js';
import { DECISIONS, getDecision, getOption } from '../data/decisions.js';
import { validateName, cleanName } from '../data/names.js';
import { applyEffects } from './resources.js';

export const SCHEMA_VERSION = 1;
export const APP_ID = 'medieval-chronicle';
export const STAGES = ['intro', 'names', 'geography', 'founding', 'founded', 'decision', 'outcome', 'sliceEnd'];
export const NAME_KEYS = ['village', 'farmer', 'craft', 'priest'];
export const DRAFT_LIMIT = 4000;
export const RELATIONSHIP_KEYS = ['landholder', 'church', 'merchants', 'crown'];

export function createInitialState(playthroughId) {
  return {
    app: APP_ID,
    schemaVersion: SCHEMA_VERSION,
    playthroughId,
    stage: 'intro',
    names: null,
    geography: null,
    founding: null,
    resources: null,
    resourceHistory: [],
    decisions: {},
    currentDecision: null,
    pending: {},
    flags: [],
    relationships: { landholder: [], church: [], merchants: [], crown: [] },
    chronicle: [],
    drafts: {}
  };
}

export function fill(template, names) {
  if (!names) return template;
  return template.replace(/\{(village|farmer|craft|priest)\}/g, (_, k) => names[k]);
}

function addFlags(s, flags) {
  for (const f of flags) if (!s.flags.includes(f)) s.flags.push(f);
}

function addChronicle(s, entry) {
  if (!s.chronicle.some((e) => e.id === entry.id)) s.chronicle.push(entry);
}

export function reduce(state, action) {
  const s = structuredClone(state);
  switch (action.type) {
    case 'ADVANCE': {
      if (state.stage === 'intro') s.stage = 'names';
      else if (state.stage === 'geography') s.stage = 'founding';
      else if (state.stage === 'founded') {
        s.stage = 'decision';
        s.currentDecision = DECISIONS[0].id;
      } else if (state.stage === 'outcome') {
        const idx = DECISIONS.findIndex((d) => d.id === state.currentDecision);
        const next = DECISIONS[idx + 1];
        if (next) {
          s.stage = 'decision';
          s.currentDecision = next.id;
        } else {
          s.stage = 'sliceEnd';
        }
      } else return state;
      return s;
    }

    case 'SET_DRAFT': {
      const { field, value } = action;
      if (typeof field !== 'string' || !/^[a-z0-9_.]{1,40}$/.test(field) || typeof value !== 'string') return state;
      s.drafts[field] = value.slice(0, DRAFT_LIMIT);
      return s;
    }

    case 'CONFIRM_NAMES': {
      if (state.stage !== 'names' || state.names) return state;
      const names = {};
      for (const k of NAME_KEYS) {
        const v = action.names?.[k];
        if (validateName(v)) return state;
        names[k] = cleanName(v);
      }
      if (!state.geography) {
        const g = GEOGRAPHIES[action.geography];
        if (!g) return state;
        s.geography = g.id;
        s.resources = { ...g.start };
        s.resourceHistory.push({ id: 'start', label: `Starting resources (${g.name})`, before: null, after: { ...g.start }, changes: [] });
      }
      s.names = names;
      s.stage = 'geography';
      return s;
    }

    case 'SELECT': {
      const { key, option } = action;
      if (key === 'founding') {
        if (state.stage !== 'founding' || state.founding || !FOUNDING_PRIORITIES[option]) return state;
      } else {
        if (state.stage !== 'decision' || key !== state.currentDecision || state.decisions[key] || !getOption(key, option)) return state;
      }
      s.pending[key] = option;
      return s;
    }

    case 'CONFIRM_FOUNDING': {
      if (state.stage !== 'founding' || state.founding) return state;
      const p = FOUNDING_PRIORITIES[state.pending.founding];
      if (!p) return state;
      const { after, changes } = applyEffects(state.resources, p.effects);
      s.resourceHistory.push({ id: 'founding', label: `Founding priority: ${p.name}`, before: { ...state.resources }, after, changes });
      s.resources = after;
      s.founding = p.id;
      delete s.pending.founding;
      addFlags(s, [`founding_${p.id}`]);
      if (p.id === 'autonomy') {
        s.relationships.landholder.push({ id: 'founding', text: '{village} keeps a strong memory of its customs, which strengthens its hand when bargaining with landholders.' });
      }
      addChronicle(s, { id: 'founding', kind: 'founding', era: 'early', year: 'c. 920', title: `The founding of ${s.names.village}` });
      s.stage = 'founded';
      return s;
    }

    case 'CONFIRM_DECISION': {
      if (state.stage !== 'decision') return state;
      const d = getDecision(state.currentDecision);
      if (!d || state.decisions[d.id]) return state;
      const opt = getOption(d.id, state.pending[d.id]);
      if (!opt) return state;
      const { after, changes } = applyEffects(state.resources, opt.effects);
      s.resourceHistory.push({ id: d.id, label: `Decision ${d.number}: ${opt.label}`, before: { ...state.resources }, after, changes });
      s.resources = after;
      s.decisions[d.id] = { option: opt.id };
      delete s.pending[d.id];
      addFlags(s, opt.flags);
      for (const [rk, text] of Object.entries(opt.relationships || {})) {
        s.relationships[rk].push({ id: d.id, text });
      }
      addChronicle(s, { id: d.id, kind: 'decision', era: d.era, year: d.year, title: `Decision ${d.number}: ${d.title}` });
      s.stage = 'outcome';
      return s;
    }

    default:
      return state;
  }
}

/** Index of the stage, for ordering checks. */
export function stageIndex(stage) {
  return STAGES.indexOf(stage);
}
