// One function per stage. Each returns a DOM node; ctx supplies dispatch and UI-only state.
import { h, tag } from './dom.js';
import { GEOGRAPHIES, GEOGRAPHY_IDS } from '../data/geographies.js';
import { FOUNDING_PRIORITIES, FOUNDING_IDS } from '../data/founding.js';
import { NAME_FIELDS, NAME_SUGGESTIONS, NAME_MAX, validateName } from '../data/names.js';
import { getDecision, getOption, TOTAL_DECISIONS } from '../data/decisions.js';
import { INTRO_920, HOW_IT_WORKS, RESOURCE_INFO, RESOURCE_NOTE, PRIVACY_NOTICE, ERAS, ROLE_LABELS } from '../data/text.js';
import { fill } from '../engine/state.js';
import { completionSummary } from '../engine/progress.js';

const H1 = (text) => h('h1', { tabindex: '-1', class: 'screen-title' }, text);

export function describeChanges(entry) {
  if (!entry || !entry.changes.length) return ['No change to resources.'];
  return entry.changes.map((c) => {
    const name = RESOURCE_INFO[c.key].name;
    const verb = c.requested > 0 ? 'risen' : 'fallen';
    const base = c.applied === 0 ? `${name} stayed at ${c.after}.` : `${name} went from ${c.before} to ${c.after}.`;
    return c.capped ? `${base} It would have ${verb} by ${Math.abs(c.requested)}, but resources stay between 1 and 5.` : base;
  });
}

function changesBlock(entry) {
  return h('ul', { class: 'changes' }, describeChanges(entry).map((t) => h('li', null, t)));
}

function optionList(name, legend, options, selected, onSelect) {
  return h('fieldset', { class: 'options' },
    h('legend', null, legend),
    options.map((o) =>
      h('label', { class: o.id === selected ? 'option is-selected' : 'option', for: `opt-${name}-${o.id}` },
        h('input', { type: 'radio', name, id: `opt-${name}-${o.id}`, value: o.id, checked: o.id === selected, onchange: () => onSelect(o.id) }),
        h('span', { class: 'option-body' }, h('span', { class: 'option-title' }, o.label), h('span', { class: 'option-desc' }, o.description))
      )
    )
  );
}

function confirmBlock(ctx, key, selectedLabel, actionType) {
  if (!selectedLabel) return h('p', { class: 'confirm-hint' }, 'Choose an option to continue. You can change your mind until you confirm.');
  if (ctx.ui.confirming === key) {
    return h('div', { class: 'confirm-box', role: 'group', 'aria-labelledby': 'confirm-q' },
      h('p', { id: 'confirm-q' }, `Confirm “${selectedLabel}”? You can’t change this choice afterward.`),
      h('div', { class: 'button-row' },
        h('button', { type: 'button', class: 'btn btn-primary', id: 'confirm-yes', onclick: () => ctx.dispatch({ type: actionType }) }, 'Yes, confirm'),
        h('button', { type: 'button', class: 'btn', id: 'confirm-no', onclick: () => ctx.setUi({ confirming: null }, `confirm-btn-${key}`) }, 'Keep thinking')
      )
    );
  }
  return h('div', { class: 'button-row' },
    h('button', { type: 'button', class: 'btn btn-primary', id: `confirm-btn-${key}`, onclick: () => ctx.setUi({ confirming: key }, 'confirm-yes') }, 'Confirm choice')
  );
}

function voicesBlock(voices, names) {
  return h('ul', { class: 'voices', 'aria-label': 'What the founders say' },
    voices.map((v) => h('li', null, h('span', { class: 'voice-who' }, `${names[v.who]}, the ${ROLE_LABELS[v.who]}`), h('q', null, fill(v.text, names))))
  );
}

function eraLine(eraId, year) {
  const e = ERAS[eraId];
  return h('p', { class: 'era-line' }, `${e.chapter}: ${e.title}`, h('span', { class: 'era-year' }, year));
}

// ---------- Screens ----------

export function introScreen(state, ctx) {
  return h('div', { class: 'screen screen-intro' },
    H1('The Medieval Chronicle'),
    h('p', { class: 'lede' }, 'Guide an English village through more than four centuries of change, from about 920 to 1381.'),
    h('section', { class: 'card history-note', 'aria-labelledby': 'eng-920' },
      h('h2', { id: 'eng-920' }, 'England around 920 ', tag('history')),
      INTRO_920.map((p) => h('p', null, p))
    ),
    h('section', { 'aria-labelledby': 'how' },
      h('h2', { id: 'how' }, 'How this works'),
      h('ul', { class: 'plain-list' }, HOW_IT_WORKS.map((t) => h('li', null, t))),
      h('p', null, 'Your village and its people are invented. The events, laws, and sources marked “Real history” are documented.')
    ),
    h('details', { class: 'privacy' }, h('summary', null, 'Where is my work saved?'), PRIVACY_NOTICE.map((p) => h('p', null, p))),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', id: 'begin', onclick: () => ctx.dispatch({ type: 'ADVANCE' }) }, 'Begin your village'))
  );
}

export function namesScreen(state, ctx) {
  const errors = ctx.ui.nameErrors || {};
  const onSubmit = (e) => {
    e.preventDefault();
    const names = {};
    const errs = {};
    for (const f of NAME_FIELDS) {
      const v = document.getElementById(`name-${f.key}`).value;
      names[f.key] = v;
      const err = validateName(v);
      if (err) errs[f.key] = err;
    }
    const first = NAME_FIELDS.find((f) => errs[f.key]);
    if (first) {
      ctx.setUi({ nameErrors: errs }, `name-${first.key}`);
      return;
    }
    const geography = GEOGRAPHY_IDS[ctx.randomIndex(GEOGRAPHY_IDS.length)];
    ctx.setUi({ nameErrors: {} });
    ctx.dispatch({ type: 'CONFIRM_NAMES', names, geography });
  };
  return h('div', { class: 'screen screen-names' },
    H1('Name your village and its founders'),
    h('p', null, 'Choose a suggestion or type your own. These founders’ names stay fixed in your Chronicle; later generations will have their own.'),
    h('form', { novalidate: true, onsubmit: onSubmit },
      NAME_FIELDS.map((f) => {
        const id = `name-${f.key}`;
        const err = errors[f.key];
        const draftKey = `name.${f.key}`;
        return h('div', { class: err ? 'field has-error' : 'field' },
          h('label', { for: id }, f.label),
          h('p', { class: 'field-hint', id: `${id}-hint` }, f.hint),
          h('input', {
            type: 'text', id, name: f.key, maxlength: NAME_MAX, autocomplete: 'off', spellcheck: 'false',
            value: state.drafts[draftKey] || '',
            'aria-describedby': `${id}-hint${err ? ` ${id}-err` : ''}`,
            'aria-invalid': err ? 'true' : null,
            oninput: (e) => ctx.draft(draftKey, e.target.value)
          }),
          err ? h('p', { class: 'field-error', id: `${id}-err` }, err) : null,
          h('div', { class: 'suggestions', role: 'group', 'aria-label': `Suggestions for ${f.label.toLowerCase()}` },
            NAME_SUGGESTIONS[f.key].map((n) =>
              h('button', { type: 'button', class: 'chip', onclick: () => {
                const input = document.getElementById(id);
                input.value = n;
                ctx.draft(draftKey, n);
                input.focus();
              } }, n)
            )
          )
        );
      }),
      h('div', { class: 'button-row' }, h('button', { type: 'submit', class: 'btn btn-primary' }, 'Found the village'))
    )
  );
}

export function geographyScreen(state, ctx) {
  const g = GEOGRAPHIES[state.geography];
  const n = state.names;
  return h('div', { class: 'screen screen-geo' },
    H1(`Your land: ${g.name}`),
    h('p', { class: 'lede' }, `${n.village} lies ${g.region}. ${g.description}`),
    h('p', null, 'Every class has villages in all four kinds of land. Yours was assigned at random. Each has strengths and challenges, and none is better overall.'),
    h('dl', { class: 'pairs' }, h('dt', null, 'Strengths'), h('dd', null, g.strengths), h('dt', null, 'Challenges'), h('dd', null, g.challenges)),
    h('section', { class: 'card history-note' }, h('h2', null, 'This kind of land ', tag('history')), h('p', null, g.history)),
    h('section', { 'aria-labelledby': 'res-h' },
      h('h2', { id: 'res-h' }, 'Your starting resources'),
      h('p', null, RESOURCE_NOTE),
      h('dl', { class: 'resource-defs' }, Object.entries(RESOURCE_INFO).map(([k, r]) => [h('dt', null, `${r.name}: ${state.resources[k]} of 5`), h('dd', null, r.meaning)]))
    ),
    h('p', null, `Your founders are ${n.farmer} the farmer, ${n.craft} the craftworker, and ${n.priest} the priest.`),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ctx.dispatch({ type: 'ADVANCE' }) }, 'Choose a founding priority'))
  );
}

export function foundingScreen(state, ctx) {
  const sel = state.pending.founding;
  const opts = FOUNDING_IDS.map((id) => ({ id, label: FOUNDING_PRIORITIES[id].name, description: FOUNDING_PRIORITIES[id].description }));
  return h('div', { class: 'screen' },
    eraLine('early', 'c. 920'),
    H1('What matters most to the founders?'),
    h('p', null, `This becomes part of ${state.names.village}’s identity. Later choices can go in a different direction, and you will look back on it at the end.`),
    optionList('founding', 'Founding priority', opts, sel, (id) => ctx.select('founding', id)),
    confirmBlock(ctx, 'founding', sel && FOUNDING_PRIORITIES[sel].name, 'CONFIRM_FOUNDING')
  );
}

export function foundedScreen(state, ctx) {
  const p = FOUNDING_PRIORITIES[state.founding];
  const entry = state.resourceHistory.find((r) => r.id === 'founding');
  return h('div', { class: 'screen' },
    eraLine('early', 'c. 920'),
    H1(`${state.names.village} is founded`),
    h('p', { class: 'lede' }, `Founding priority: ${p.name}. ${p.outcome}`),
    h('section', { 'aria-labelledby': 'eff' }, h('h2', { id: 'eff' }, 'Effects on resources'), changesBlock(entry)),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ctx.dispatch({ type: 'ADVANCE' }) }, 'Go to Decision 1'))
  );
}

export function decisionScreen(state, ctx) {
  const d = getDecision(state.currentDecision);
  const n = state.names;
  const sel = state.pending[d.id];
  const opt = sel ? getOption(d.id, sel) : null;
  return h('div', { class: 'screen' },
    eraLine(d.era, d.year),
    H1(`Decision ${d.number}: ${d.title}`),
    h('div', { class: 'story' }, tag('sim'), d.setup.map((p) => h('p', null, fill(p, n)))),
    voicesBlock(d.voices, n),
    optionList(d.id, d.prompt, d.options, sel, (id) => ctx.select(d.id, id)),
    opt
      ? h('section', { class: 'preview', 'aria-labelledby': 'prev-h' },
          h('h2', { id: 'prev-h' }, `If you choose “${opt.label}”`),
          h('dl', { class: 'pairs' }, h('dt', null, 'Possible benefits'), h('dd', null, fill(opt.preview.benefits, n)), h('dt', null, 'Possible risks'), h('dd', null, fill(opt.preview.risks, n))),
          h('p', { class: 'note' }, 'Exact effects on resources appear after you confirm.')
        )
      : null,
    confirmBlock(ctx, d.id, opt && opt.label, 'CONFIRM_DECISION')
  );
}

export function outcomeScreen(state, ctx) {
  const d = getDecision(state.currentDecision);
  const opt = getOption(d.id, state.decisions[d.id].option);
  const n = state.names;
  const entry = state.resourceHistory.find((r) => r.id === d.id);
  const rel = Object.values(opt.relationships || {});
  return h('div', { class: 'screen' },
    eraLine(d.era, d.year),
    H1(`Outcome: ${opt.label}`),
    h('section', { 'aria-labelledby': 'eff' }, h('h2', { id: 'eff' }, 'Effects on resources'), changesBlock(entry)),
    h('section', { class: 'story', 'aria-labelledby': 'what' }, h('h2', { id: 'what' }, 'What happened ', tag('sim')), opt.outcome.narrative.map((p) => h('p', null, fill(p, n)))),
    rel.length ? h('section', { 'aria-labelledby': 'rel' }, h('h2', { id: 'rel' }, 'Relationships'), rel.map((t) => h('p', null, fill(t, n)))) : null,
    h('section', { 'aria-labelledby': 'leg' }, h('h2', { id: 'leg' }, `Legacy in ${n.village} `, tag('sim')), h('p', null, fill(opt.outcome.legacy, n))),
    h('section', { class: 'card history-note', 'aria-labelledby': 'hist' }, h('h2', { id: 'hist' }, 'In real history ', tag('history')), h('p', null, opt.outcome.history)),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ctx.dispatch({ type: 'ADVANCE' }) }, 'Continue'))
  );
}

export function sliceEndScreen(state, ctx) {
  const summary = completionSummary(state);
  return h('div', { class: 'screen' },
    eraLine('early', 'c. 920'),
    H1('End of this test build'),
    h('p', { class: 'lede' }, `You have made ${Object.keys(state.decisions).length} of ${TOTAL_DECISIONS} decisions. Decisions 2 to 9, the four sources, reflections, and the final argument arrive in the next build.`),
    h('section', { 'aria-labelledby': 'prog' },
      h('h2', { id: 'prog' }, 'Your progress'),
      h('ul', { class: 'checklist' }, summary.items.map((i) => h('li', null, `${i.done >= i.total ? 'Done' : 'Not yet'}: ${i.label}, ${i.done} of ${i.total}`)))
    ),
    h('p', { class: 'reminder' }, 'In class, keep about 17 minutes at the end for your final argument and 5 minutes to download and submit your report.'),
    h('div', { class: 'button-row' },
      h('button', { type: 'button', class: 'btn btn-primary', onclick: () => ctx.openReport() }, 'Download Village History Report'),
      h('button', { type: 'button', class: 'btn', onclick: () => ctx.downloadBackup() }, 'Download backup (optional)')
    )
  );
}

export function pausedScreen(state, ctx) {
  return h('div', { class: 'screen' },
    H1('Your progress is saved'),
    h('p', { class: 'lede' }, 'You can close this tab now. Open the same link on this Chromebook, in this browser, to continue where you left off.'),
    PRIVACY_NOTICE.slice(1, 2).map((p) => h('p', null, p)),
    h('div', { class: 'button-row' },
      h('button', { type: 'button', class: 'btn btn-primary', id: 'resume', onclick: () => ctx.setUi({ paused: false }) }, 'Resume'),
      h('button', { type: 'button', class: 'btn', onclick: () => ctx.downloadBackup() }, 'Download backup')
    )
  );
}

export const SCREENS = {
  intro: introScreen,
  names: namesScreen,
  geography: geographyScreen,
  founding: foundingScreen,
  founded: foundedScreen,
  decision: decisionScreen,
  outcome: outcomeScreen,
  sliceEnd: sliceEndScreen
};
