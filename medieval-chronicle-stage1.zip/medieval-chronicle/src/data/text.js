// General student-facing text. Keep it short, concrete, and readable for 10th graders.

export const INTRO_920 = [
  'Around 920, there is no single kingdom of England. Kings of Wessex, descendants of Alfred the Great, are extending their rule. King Edward the Elder now controls the south and much of the Midlands and East Anglia.',
  'Much of the north, including York, is still ruled by Scandinavian kings, and Scandinavian settlers live across the east. Most people live in small farming communities. They owe customary duties to local landholders and look to the Church for worship and help.'
];

export const HOW_IT_WORKS = [
  'You will guide one village from about 920 to about 1381.',
  'You will make nine decisions, read four real historical sources, and write short reflections.',
  'At the end, you will write a historical argument and download a PDF report to submit in Canvas.'
];

export const RESOURCE_INFO = {
  food: { name: 'Food', meaning: 'How well the village can feed itself through the year.' },
  population: { name: 'Population', meaning: 'The number and health of the people living here. It is not a measure of anyone’s worth.' },
  wealth: { name: 'Wealth', meaning: 'Goods, coin, livestock, and tools the village can spare or trade.' },
  stability: { name: 'Stability', meaning: 'How well the village can manage disputes and disruptions. It is not obedience to a lord.' }
};

export const RESOURCE_NOTE =
  'Each resource runs from 1 to 5. No combination is the “right” one, and there is no winning score.';

export const PRIVACY_NOTICE = [
  'Your work is saved only in this browser on this device. Nothing is sent to a server, and there is no login or tracking.',
  'Clearing browser data, using a guest or incognito window, or switching Chromebooks can erase your progress. Download a backup file if you want extra safety.',
  'Your teacher sees your work only when you download the PDF report and submit it in Canvas.'
];

export const ERAS = {
  early: { chapter: 'Chapter I', title: 'A Village Takes Root', span: 'c. 920–970' },
  high: { chapter: 'Chapter II', title: 'Growth and Opportunity', span: 'c. 1120–1250' },
  late: { chapter: 'Chapter III', title: 'Crisis and Change', span: 'c. 1348–1381' }
};

export const ROLE_LABELS = {
  farmer: 'farmer',
  craft: 'craftworker',
  priest: 'priest'
};
