# Source verification status

No source excerpts are included in Stage 1. Stage 3 adds the four required source cards.

Per the project rules, no quotation will be published until its exact wording, translator, edition, and provenance are confirmed. Any excerpt that cannot be verified will ship marked **UNVERIFIED PLACEHOLDER — DO NOT DEPLOY**, and the app will refuse to treat it as complete.

| # | Source | Status | Notes for verification |
|---|---|---|---|
| 1 | Legislation of King Æthelstan (c. 925–939) | Not started | Separate issuance date from manuscript transmission; surviving tithe wording may reflect later revision. |
| 2 | Henry Knighton, *Chronicle* (late 14th c.) | Not started | Confirm translator and edition for any passage on deserted villages, land, and labour. |
| 3 | Great Horwood manor court, Alice Aboveton, 1318 | Not started | Verify names and terms against an edited court record. No invented first-person quotation. Label clearly as before the plague. |
| 4 | *Anonimalle Chronicle*, 1381 | Not started | Attribute demands to the chronicler's account; do not imply demands were enacted. |

Excerpts will be short (about 50–100 words with context) and drawn from public-domain or properly licensed translations.
