import { h, announce, tag } from './ui/dom.js';
import { createInitialState, reduce, fill } from './engine/state.js';
import { progressLabel, completionSummary } from './engine/progress.js';
import { deriveMap } from './engine/map-model.js';
import { parseBackup } from './engine/backup.js';
import { RESOURCE_KEYS } from './engine/resources.js';
import { GEOGRAPHIES } from './data/geographies.js';
import { FOUNDING_PRIORITIES } from './data/founding.js';
import { getDecision, getOption } from './data/decisions.js';
import { RESOURCE_INFO, PRIVACY_NOTICE } from './data/text.js';
import { SCREENS, pausedScreen, describeChanges } from './ui/screens.js';
import { renderMapPanel } from './ui/map.js';
import { loadSaved, save, storageStatus, downloadBackup, downloadBlob } from './ui/storage.js';
import { buildReport, reportFilename } from './export/report.js';

// ---------- State ----------
const newId = () => (crypto.randomUUID ? crypto.randomUUID() : `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`);
const startupError = { message: '' };
let state = loadSaved();
if (!state) {
  startupError.message = storageStatus().lastError;
  state = createInitialState(newId());
}

// UI-only state. Not saved. The student's name for the PDF lives here only.
const ui = { confirming: null, nameErrors: {}, paused: false, place: null, studentName: '', dialog: null, importCandidate: null, dialogMessage: '' };

// ---------- Persistence ----------
let saveTimer = null;
function saveNow() {
  clearTimeout(saveTimer);
  saveTimer = null;
  save(state);
  updateSaveStatus();
}
function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 400);
}
document.addEventListener('visibilitychange', () => document.visibilityState === 'hidden' && saveNow());
window.addEventListener('pagehide', saveNow);

// ---------- Actions ----------
function dispatch(action) {
  const next = reduce(state, action);
  if (next === state) return;
  const prev = state;
  state = next;
  ui.confirming = null;
  saveNow();
  render();
  announceTransition(prev, next);
}

function announceTransition(prev, next) {
  if (prev.stage === next.stage && prev.currentDecision === next.currentDecision) return;
  const latest = next.resourceHistory[next.resourceHistory.length - 1];
  if ((next.stage === 'outcome' || next.stage === 'founded') && latest) {
    announce(describeChanges(latest).join(' '));
  }
}

const ctx = {
  ui,
  dispatch,
  draft(field, value) {
    const next = reduce(state, { type: 'SET_DRAFT', field, value });
    if (next !== state) {
      state = next;
      saveSoon();
    }
  },
  select(key, option) {
    const next = reduce(state, { type: 'SELECT', key, option });
    if (next === state) return;
    state = next;
    ui.confirming = null;
    saveNow();
    render();
  },
  setUi(patch, focusId) {
    Object.assign(ui, patch);
    render(focusId);
  },
  randomIndex(n) {
    const a = new Uint32Array(1);
    crypto.getRandomValues(a);
    return a[0] % n;
  },
  openReport: () => openDialog('report'),
  downloadBackup: () => {
    saveNow();
    downloadBackup(state);
    announce('Backup file downloaded.');
  }
};

// ---------- Rendering ----------
const app = document.getElementById('app');
let lastView = '';

function render(focusId) {
  const activeId = focusId || document.activeElement?.id;
  const view = ui.paused ? 'paused' : `${state.stage}:${state.currentDecision || ''}`;
  const screenFn = ui.paused ? pausedScreen : SCREENS[state.stage];

  app.replaceChildren(
    ...[header(), banner()].filter(Boolean),
    h('div', { class: state.geography ? 'layout' : 'layout layout-single' },
      h('main', { id: 'main', class: 'narrative' }, screenFn(state, ctx)),
      state.geography && !ui.paused ? sidePanel() : null
    )
  );

  if (view !== lastView && !focusId) {
    lastView = view;
    window.scrollTo({ top: 0 });
    app.querySelector('.screen-title')?.focus();
  } else {
    lastView = view;
    const el = activeId && document.getElementById(activeId);
    if (el) el.focus();
  }
  if (ui.dialog) renderDialogBody();
}

function header() {
  const p = progressLabel(state);
  return h('header', { class: 'topbar' },
    h('div', { class: 'brand' },
      h('span', { class: 'brand-app' }, 'The Medieval Chronicle'),
      state.names ? h('span', { class: 'brand-village' }, state.names.village) : null
    ),
    h('p', { class: 'progress', 'aria-label': 'Progress' },
      p.era ? h('span', null, `${p.era.chapter}, ${p.year}`) : null,
      h('span', { class: 'progress-step' }, p.text)
    ),
    h('nav', { class: 'menu', 'aria-label': 'Tools' },
      h('button', { type: 'button', class: 'menu-btn', id: 'menu-chronicle', onclick: () => openDialog('chronicle') }, 'Chronicle'),
      h('button', { type: 'button', class: 'menu-btn menu-report', id: 'menu-report', onclick: () => openDialog('report') }, 'Download report'),
      h('button', { type: 'button', class: 'menu-btn', id: 'menu-backup', onclick: () => openDialog('backup') }, 'Backup'),
      h('button', { type: 'button', class: 'menu-btn', id: 'menu-exit', onclick: () => { saveNow(); ctx.setUi({ paused: true }); } }, 'Save & exit'),
      h('button', { type: 'button', class: 'menu-btn', id: 'menu-about', onclick: () => openDialog('about') }, 'About'),
      h('span', { class: 'save-status', id: 'save-status' })
    )
  );
}

function updateSaveStatus() {
  const el = document.getElementById('save-status');
  if (!el) return;
  const st = storageStatus();
  el.textContent = st.available ? 'Saved in this browser' : 'Not saving';
  el.classList.toggle('is-warning', !st.available);
}

function banner() {
  const st = storageStatus();
  const msg = startupError.message || (!st.available ? st.lastError : '');
  if (!msg) return null;
  return h('div', { class: 'banner', role: 'alert' },
    h('p', null, msg, ' Download a backup or your report often so you don’t lose work.')
  );
}

function sidePanel() {
  const latest = state.resourceHistory[state.resourceHistory.length - 1];
  const showDelta = (state.stage === 'outcome' || state.stage === 'founded') && latest;
  const delta = (k) => {
    const c = showDelta && latest.changes.find((x) => x.key === k);
    if (!c) return null;
    return h('span', { class: 'delta' }, c.applied > 0 ? `up ${c.applied}` : c.applied < 0 ? `down ${-c.applied}` : 'capped');
  };
  return h('aside', { class: 'side', 'aria-label': 'Village status' },
    h('section', { class: 'resources', 'aria-labelledby': 'res-title' },
      h('h2', { id: 'res-title', class: 'panel-title' }, 'Resources'),
      h('ul', { class: 'res-list' },
        RESOURCE_KEYS.map((k) => {
          const v = state.resources[k];
          return h('li', null,
            h('span', { class: 'res-name' }, RESOURCE_INFO[k].name),
            h('span', { class: 'pips', 'aria-hidden': 'true' }, [1, 2, 3, 4, 5].map((i) => h('span', { class: i <= v ? 'pip is-on' : 'pip' }))),
            h('span', { class: 'res-value' }, `${v} of 5`),
            delta(k)
          );
        })
      ),
      h('details', { class: 'res-help' }, h('summary', null, 'What do these mean?'),
        h('dl', null, RESOURCE_KEYS.map((k) => [h('dt', null, RESOURCE_INFO[k].name), h('dd', null, RESOURCE_INFO[k].meaning)])))
    ),
    renderMapPanel(deriveMap(state), state.names.village, ui.place, (id) => ctx.setUi({ place: id }, `place-${id}`))
  );
}

// ---------- Dialogs ----------
let dialogEl = null;

function openDialog(kind) {
  ui.dialog = kind;
  ui.dialogMessage = '';
  ui.importCandidate = null;
  if (!dialogEl) {
    dialogEl = h('dialog', { class: 'dialog', 'aria-labelledby': 'dialog-title' });
    dialogEl.addEventListener('close', () => {
      ui.dialog = null;
      ui.importCandidate = null;
    });
    document.body.append(dialogEl);
  }
  renderDialogBody();
  if (!dialogEl.open) dialogEl.showModal();
  dialogEl.querySelector('h2')?.focus();
}

function closeDialog() {
  dialogEl?.close();
}

function renderDialogBody(focusId) {
  if (!dialogEl || !ui.dialog) return;
  const bodies = { chronicle: chronicleBody, report: reportBody, backup: backupBody, about: aboutBody };
  dialogEl.replaceChildren(
    h('div', { class: 'dialog-inner' },
      bodies[ui.dialog](),
      ui.dialogMessage ? h('p', { class: 'dialog-message', role: 'status' }, ui.dialogMessage) : null,
      h('div', { class: 'button-row dialog-close' }, h('button', { type: 'button', class: 'btn', id: 'dialog-close', onclick: closeDialog }, 'Close'))
    )
  );
  if (focusId) document.getElementById(focusId)?.focus();
}

function chronicleBody() {
  const n = state.names;
  const entries = state.chronicle.map((e) => {
    if (e.kind === 'founding') {
      const g = GEOGRAPHIES[state.geography];
      const p = FOUNDING_PRIORITIES[state.founding];
      return h('li', { class: 'chron-entry' },
        h('h3', null, h('span', { class: 'chron-year' }, e.year), e.title, ' ', tag('sim')),
        h('p', null, `Founded ${g.region} (${g.name}). Founders: ${n.farmer} the farmer, ${n.craft} the craftworker, and ${n.priest} the priest.`),
        h('p', null, `Founding priority: ${p.name}. ${describeChanges(state.resourceHistory.find((r) => r.id === 'founding')).join(' ')}`)
      );
    }
    const d = getDecision(e.id);
    const opt = getOption(d.id, state.decisions[d.id].option);
    return h('li', { class: 'chron-entry' },
      h('h3', null, h('span', { class: 'chron-year' }, e.year), e.title, ' ', tag('sim')),
      h('p', null, `Choice: ${opt.label}. ${describeChanges(state.resourceHistory.find((r) => r.id === d.id)).join(' ')}`),
      h('p', null, fill(opt.outcome.legacy, n))
    );
  });
  const rel = Object.entries(state.relationships).flatMap(([k, list]) => list.map((r) => ({ k, text: fill(r.text, n) })));
  return [
    h('h2', { id: 'dialog-title', tabindex: '-1' }, state.names ? `The Chronicle of ${n.village}` : 'Your Chronicle'),
    entries.length ? h('ol', { class: 'chronicle' }, entries) : h('p', null, 'Your Chronicle is empty. It fills in as you found the village and make decisions.'),
    rel.length ? [h('h3', null, 'Relationships'), h('ul', { class: 'plain-list' }, rel.map((r) => h('li', null, r.text)))] : null
  ];
}

function reportBody() {
  const summary = completionSummary(state);
  return [
    h('h2', { id: 'dialog-title', tabindex: '-1' }, 'Download Village History Report'),
    h('p', null, 'You can download your report at any time. Unfinished sections are marked “Not completed.”'),
    h('p', null, `Status: ${summary.complete ? 'Complete' : 'Incomplete'}.`),
    h('div', { class: 'field' },
      h('label', { for: 'student-name' }, 'Your name (optional)'),
      h('p', { class: 'field-hint', id: 'student-name-hint' }, 'Printed on the PDF so your teacher knows it is yours. It is not saved anywhere.'),
      h('input', { type: 'text', id: 'student-name', maxlength: 60, autocomplete: 'name', value: ui.studentName, 'aria-describedby': 'student-name-hint', oninput: (e) => (ui.studentName = e.target.value) })
    ),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', id: 'do-report', onclick: makeReport }, 'Download PDF')),
    h('p', { class: 'note' }, 'After it downloads, find the file in your Downloads folder and upload it to the Canvas assignment.')
  ];
}

function makeReport() {
  const JsPDF = window.jspdf?.jsPDF;
  if (!JsPDF) {
    ui.dialogMessage = 'The PDF tool did not load. Reload the page and try again.';
    renderDialogBody('do-report');
    return;
  }
  try {
    saveNow();
    const generatedAt = new Date().toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'short' });
    const doc = buildReport(JsPDF, state, { studentName: ui.studentName, generatedAt });
    downloadBlob(doc.output('blob'), reportFilename(state));
    ui.dialogMessage = 'Report downloaded. Find it in your Downloads folder, then upload it to Canvas.';
  } catch (e) {
    console.error(e);
    ui.dialogMessage = 'The report could not be created. Download a backup, reload the page, and try again.';
  }
  renderDialogBody('do-report');
}

function backupBody() {
  const cand = ui.importCandidate;
  return [
    h('h2', { id: 'dialog-title', tabindex: '-1' }, 'Backup'),
    h('p', null, PRIVACY_NOTICE[1]),
    h('div', { class: 'button-row' }, h('button', { type: 'button', class: 'btn btn-primary', id: 'do-backup', onclick: () => { ctx.downloadBackup(); ui.dialogMessage = 'Backup file downloaded.'; renderDialogBody('do-backup'); } }, 'Download backup file')),
    h('h3', null, 'Load a backup'),
    h('p', null, 'Loading a backup replaces the progress currently in this browser.'),
    h('div', { class: 'field' },
      h('label', { for: 'import-file' }, 'Backup file (.json)'),
      h('input', { type: 'file', id: 'import-file', accept: '.json,application/json', onchange: onImportFile })
    ),
    cand
      ? h('div', { class: 'confirm-box', role: 'group', 'aria-labelledby': 'imp-q' },
          h('p', { id: 'imp-q' }, `Replace your current progress with the backup of ${cand.names ? cand.names.village : 'a village that has not been named yet'}? Your current progress will be lost unless you download a backup first.`),
          h('div', { class: 'button-row' },
            h('button', { type: 'button', class: 'btn btn-primary', id: 'imp-yes', onclick: () => {
              state = cand;
              ui.importCandidate = null;
              ui.paused = false;
              saveNow();
              closeDialog();
              lastView = '';
              render();
              announce('Backup loaded.');
            } }, 'Yes, replace my progress'),
            h('button', { type: 'button', class: 'btn', onclick: () => { ui.importCandidate = null; renderDialogBody('import-file'); } }, 'Cancel')
          )
        )
      : null
  ];
}

function onImportFile(e) {
  const file = e.target.files?.[0];
  if (!file) return;
  if (file.size > 500_000) {
    ui.dialogMessage = 'This file is too large to be a Medieval Chronicle backup.';
    renderDialogBody('import-file');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    const result = parseBackup(String(reader.result));
    ui.importCandidate = result.ok ? result.state : null;
    ui.dialogMessage = result.ok ? '' : result.error;
    renderDialogBody(result.ok ? 'imp-yes' : 'import-file');
  };
  reader.onerror = () => {
    ui.dialogMessage = 'The file could not be read.';
    renderDialogBody('import-file');
  };
  reader.readAsText(file);
}

function aboutBody() {
  return [
    h('h2', { id: 'dialog-title', tabindex: '-1' }, 'About and privacy'),
    PRIVACY_NOTICE.map((p) => h('p', null, p)),
    h('h3', null, 'Simulation and real history'),
    h('p', null, 'Your village and its people are invented. Text labelled “Simulation” is fiction based on what was historically plausible. Text labelled “Real history” describes documented events and sources.'),
    h('p', { class: 'note' }, 'Version 0.1 (Stage 1 test build).')
  ];
}

render();
updateSaveStatus();
