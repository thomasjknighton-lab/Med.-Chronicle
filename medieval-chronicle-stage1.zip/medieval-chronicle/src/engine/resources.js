export const RESOURCE_KEYS = ['food', 'population', 'wealth', 'stability'];
export const RES_MIN = 1;
export const RES_MAX = 5;

export function clamp(n) {
  return Math.max(RES_MIN, Math.min(RES_MAX, n));
}

/**
 * Apply deltas with clamping. Returns the new resources and an exact record of each
 * requested change, the change actually applied, and whether a cap suppressed it.
 */
export function applyEffects(resources, effects = {}) {
  const after = { ...resources };
  const changes = [];
  for (const key of RESOURCE_KEYS) {
    const requested = effects[key] || 0;
    if (!requested) continue;
    const before = resources[key];
    const value = clamp(before + requested);
    after[key] = value;
    changes.push({ key, before, after: value, requested, applied: value - before, capped: value - before !== requested });
  }
  return { after, changes };
}
