# Manual QA checklist

Run on an actual school Chromebook, signed in as a student, before classroom use.

## Stage 1 (current build)

- [ ] Site loads from the GitHub Pages URL (inside the repository subfolder).
- [ ] Intro: "Begin your village" works by mouse and by keyboard (Tab, Enter).
- [ ] Names: submitting with empty fields shows an error on each field and focuses the first one.
- [ ] Names: suggestion buttons fill the field; custom names with Æ, hyphens, and apostrophes are accepted; `<` and blocked words are rejected.
- [ ] Partially typed names survive a reload.
- [ ] Geography appears with starting resources. Reloading shows the **same** geography.
- [ ] Founding priority: selection can change before confirming; "Confirm choice" asks for a second confirmation; "Keep thinking" cancels.
- [ ] Founding result shows the exact resource change, including a note if a cap stopped it.
- [ ] Decision 1: previews show benefits and risks in words, no numbers.
- [ ] A selected-but-unconfirmed option survives a reload.
- [ ] After confirming, the outcome screen shows exact changes, narrative, legacy (Simulation), and real-history note.
- [ ] Reloading on the outcome screen does **not** apply the change again (check resource values).
- [ ] The map shows new features with dashed outlines and "(new)" labels; place buttons show descriptions.
- [ ] Chronicle lists the founding and Decision 1.
- [ ] Download report works at the intro (empty), mid-way, and at the end. Missing sections read "Not completed."
- [ ] The PDF opens, prints legibly in black and white, and uploads to a Canvas assignment.
- [ ] Download backup → open the site in a new Incognito window → Backup → load file → confirmation → progress restored.
- [ ] Loading a non-backup file or an edited backup shows a clear error and changes nothing.
- [ ] Save & exit shows the saved screen; Resume returns to the same place.
- [ ] With ChromeVox on, outcome changes are announced.
- [ ] At 200% zoom, nothing is cut off; the side panel moves below the story.
- [ ] Turn off Wi-Fi after the page has loaded: PDF download still works.

## Later stages

Added as features arrive: all nine decisions × four geographies, plague effect applies regardless of trade or travel choices, sources cannot be skipped, required reflections and justifications, final argument autosave, complete PDF, epilogue maps.
