// Tiny DOM builder. All strings become text nodes or attributes; nothing is parsed as HTML.
export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  setProps(el, props);
  append(el, children);
  return el;
}

const SVG_NS = 'http://www.w3.org/2000/svg';
export function s(tag, props, ...children) {
  const el = document.createElementNS(SVG_NS, tag);
  setProps(el, props);
  append(el, children);
  return el;
}

function setProps(el, props) {
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.setAttribute('class', v);
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked') el.checked = !!v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

let liveTimer;
export function announce(message) {
  const region = document.getElementById('live');
  if (!region) return;
  region.textContent = '';
  clearTimeout(liveTimer);
  liveTimer = setTimeout(() => (region.textContent = message), 60);
}

/** Label marking content as fictional simulation or documented history. Text, not color, carries meaning. */
export function tag(kind) {
  return kind === 'history'
    ? h('span', { class: 'tag tag-history' }, 'Real history')
    : h('span', { class: 'tag tag-sim' }, 'Simulation');
}
