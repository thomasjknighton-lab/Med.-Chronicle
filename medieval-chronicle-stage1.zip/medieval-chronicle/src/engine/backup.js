// Backup files contain choices and the student's own text only, plus a checksum.
// The checksum detects accidental damage; it is not a security feature.
import { APP_ID, SCHEMA_VERSION } from './state.js';
import { choicesFromState, rebuild } from './rebuild.js';

export function checksum(str) {
  // FNV-1a, 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

export function makeBackup(state, savedAt = '') {
  const data = choicesFromState(state);
  return { app: APP_ID, kind: 'backup', schemaVersion: SCHEMA_VERSION, savedAt, checksum: checksum(JSON.stringify(data)), data };
}

/** Parse untrusted text. Returns { ok: true, state } or { ok: false, error }. */
export function parseBackup(text) {
  if (typeof text !== 'string' || text.length > 500_000) return { ok: false, error: 'This file is too large to be a Medieval Chronicle backup.' };
  let obj;
  try {
    obj = JSON.parse(text);
  } catch {
    return { ok: false, error: 'This file is not a Medieval Chronicle backup. It could not be read.' };
  }
  if (!obj || obj.app !== APP_ID) return { ok: false, error: 'This file is not a Medieval Chronicle backup.' };
  if (obj.schemaVersion !== SCHEMA_VERSION) return { ok: false, error: `This backup was made by a different version (version ${String(obj.schemaVersion).slice(0, 10)}).` };
  if (typeof obj.checksum !== 'string' || checksum(JSON.stringify(obj.data)) !== obj.checksum) {
    return { ok: false, error: 'This backup file has been changed or damaged, so it cannot be loaded.' };
  }
  try {
    return { ok: true, state: rebuild(obj.data) };
  } catch (e) {
    return { ok: false, error: `This backup could not be loaded: ${e.message}` };
  }
}
