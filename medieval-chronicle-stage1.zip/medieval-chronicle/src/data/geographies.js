// Each geography starts with resources summing to 12. None is better overall.
export const GEOGRAPHY_IDS = ['river', 'coastal', 'woodland', 'upland'];

export const GEOGRAPHIES = {
  river: {
    id: 'river',
    name: 'River Valley',
    region: 'in a valley of the Thames or the Severn',
    start: { food: 4, population: 3, wealth: 3, stability: 2 },
    description:
      'Damp meadows and good grain land lie beside a river that carries boats, travellers, and news.',
    strengths: 'Rich soil and meadow hay make harvests strong.',
    challenges: 'Floods come without warning, and families quarrel over meadow and water rights.',
    history:
      'In real history, river valleys were among the most densely farmed parts of England, and rivers were important routes for moving goods.'
  },
  coastal: {
    id: 'coastal',
    name: 'Coastal',
    region: 'on the coast of East Anglia or the south',
    start: { food: 3, population: 3, wealth: 4, stability: 2 },
    description:
      'Fishing boats, salt pans, and a landing place bring goods and strangers to the shore.',
    strengths: 'Boats and salt bring trade and outside contacts.',
    challenges: 'Storms damage boats and fields, and people arriving by sea are not always friendly.',
    history:
      'In real history, coastal communities mixed farming with fishing and salt-making, and they were often first to feel the arrival of seaborne trade or raids.'
  },
  woodland: {
    id: 'woodland',
    name: 'Woodland',
    region: 'in the Weald or the Forest of Dean',
    start: { food: 3, population: 3, wealth: 2, stability: 4 },
    description:
      'Clearings are cut from thick woods where pigs feed on acorns and timber is close at hand.',
    strengths: 'A close-knit community, with timber, fuel, and woodland grazing nearby.',
    challenges: 'Good farmland is hard won, and there is little surplus to trade.',
    history:
      'In real history, woodland areas were settled in scattered clearings, and rights to wood, grazing, and pig-feeding were valuable and carefully defended.'
  },
  upland: {
    id: 'upland',
    name: 'Upland',
    region: 'in the Pennine hills of the north',
    start: { food: 2, population: 3, wealth: 3, stability: 4 },
    description:
      'Hills and moorland pasture feed sheep and cattle. Grain grows only in sheltered patches.',
    strengths: 'Families depend on one another, and livestock can be traded.',
    challenges: 'Thin soil and a short growing season make grain scarce.',
    history:
      'In real history, around 920 much of northern England was ruled by Scandinavian kings based at York, and upland communities relied heavily on livestock.'
  }
};
