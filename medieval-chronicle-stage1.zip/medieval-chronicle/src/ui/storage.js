// Browser persistence. Saved data is treated as untrusted and rebuilt from choices on load.
import { makeBackup, parseBackup } from '../engine/backup.js';
import { slug } from '../export/report.js';

const KEY = 'medievalChronicle.save.v1';
let available = true;
let lastError = '';

export function storageStatus() {
  return { available, lastError };
}

export function loadSaved() {
  let raw;
  try {
    raw = localStorage.getItem(KEY);
  } catch {
    available = false;
    lastError = 'This browser is blocking saved progress.';
    return null;
  }
  if (!raw) return null;
  const result = parseBackup(raw);
  if (!result.ok) {
    lastError = 'Saved progress in this browser was damaged and could not be loaded.';
    try {
      localStorage.setItem(`${KEY}.damaged`, raw);
    } catch {
      /* ignore */
    }
    return null;
  }
  return result.state;
}

export function save(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(makeBackup(state, new Date().toISOString())));
    available = true;
    lastError = '';
    return true;
  } catch (e) {
    available = false;
    lastError = e && e.name === 'QuotaExceededError' ? 'This browser is out of storage space, so progress is not being saved.' : 'Progress is not being saved in this browser.';
    return false;
  }
}

export function clearSaved() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function downloadBackup(state) {
  const blob = new Blob([JSON.stringify(makeBackup(state, new Date().toISOString()), null, 2)], { type: 'application/json' });
  downloadBlob(blob, `medieval-chronicle-backup-${slug(state.names?.village)}.json`);
}
