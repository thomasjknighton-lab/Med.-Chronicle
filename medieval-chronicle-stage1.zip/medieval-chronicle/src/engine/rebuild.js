// Saved and imported data are UNTRUSTED. We keep only the student's choices and their own text,
// validate them strictly, and regenerate everything else by replaying the pure reducer.
// This guarantees derived state is deterministic, prevents double-applied effects, and means
// no imported narrative or HTML is ever displayed.
import { GEOGRAPHY_IDS } from '../data/geographies.js';
import { FOUNDING_IDS } from '../data/founding.js';
import { DECISIONS, getOption } from '../data/decisions.js';
import { validateName } from '../data/names.js';
import { createInitialState, reduce, STAGES, NAME_KEYS, DRAFT_LIMIT, stageIndex } from './state.js';

/** The minimal record we persist. */
export function choicesFromState(state) {
  return {
    playthroughId: state.playthroughId,
    stage: state.stage,
    names: state.names,
    geography: state.geography,
    founding: state.founding,
    decisions: Object.fromEntries(Object.entries(state.decisions).map(([k, v]) => [k, v.option])),
    pending: { ...state.pending },
    drafts: { ...state.drafts }
  };
}

const isObj = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);

export function validateChoices(c) {
  const errors = [];
  if (!isObj(c)) return ['The saved data is not in the expected format.'];
  if (typeof c.playthroughId !== 'string' || !/^[A-Za-z0-9-]{4,64}$/.test(c.playthroughId)) errors.push('Missing or invalid playthrough ID.');
  if (!STAGES.includes(c.stage)) errors.push('Unknown stage.');
  if (c.names !== null) {
    if (!isObj(c.names)) errors.push('Names are invalid.');
    else for (const k of NAME_KEYS) if (validateName(c.names[k])) errors.push(`Name "${k}" is invalid.`);
  }
  if (c.geography !== null && !GEOGRAPHY_IDS.includes(c.geography)) errors.push('Unknown geography.');
  if (c.founding !== null && !FOUNDING_IDS.includes(c.founding)) errors.push('Unknown founding priority.');
  if (!isObj(c.decisions)) errors.push('Decisions are invalid.');
  else {
    const ids = Object.keys(c.decisions);
    // Confirmed decisions must form an unbroken sequence from Decision 1.
    ids.forEach((id) => {
      if (!getOption(id, c.decisions[id])) errors.push(`Decision "${id}" has an unknown option.`);
    });
    const order = DECISIONS.map((d) => d.id);
    const expected = order.slice(0, ids.length);
    if (ids.some((id) => !expected.includes(id))) errors.push('Decisions are out of order.');
    if (ids.length && (!c.founding || !c.geography || !c.names)) errors.push('Decisions recorded before founding.');
  }
  if (c.founding && (!c.geography || !c.names)) errors.push('Founding recorded before names or geography.');
  if (c.geography && !c.names) errors.push('Geography recorded before names.');
  if (!isObj(c.pending)) errors.push('Pending selections are invalid.');
  if (!isObj(c.drafts)) errors.push('Saved text is invalid.');
  else for (const [k, v] of Object.entries(c.drafts)) {
    if (!/^[a-z0-9_.]{1,40}$/.test(k) || typeof v !== 'string' || v.length > DRAFT_LIMIT) errors.push('Saved text is invalid.');
  }
  return errors;
}

/** Rebuild a full state from validated choices. Throws if choices are invalid. */
export function rebuild(c) {
  const errors = validateChoices(c);
  if (errors.length) throw new Error(errors[0]);
  let s = createInitialState(c.playthroughId);
  const step = (action) => {
    const next = reduce(s, action);
    if (next === s) throw new Error(`Saved progress could not be replayed (${action.type}).`);
    s = next;
  };
  if (stageIndex(c.stage) >= stageIndex('names')) step({ type: 'ADVANCE' });
  if (c.names) step({ type: 'CONFIRM_NAMES', names: c.names, geography: c.geography });
  if (c.founding) {
    step({ type: 'ADVANCE' });
    step({ type: 'SELECT', key: 'founding', option: c.founding });
    step({ type: 'CONFIRM_FOUNDING' });
  }
  const confirmed = DECISIONS.filter((d) => c.decisions[d.id]);
  confirmed.forEach((d) => {
    step({ type: 'ADVANCE' }); // founded -> decision, or outcome -> next decision
    step({ type: 'SELECT', key: d.id, option: c.decisions[d.id] });
    step({ type: 'CONFIRM_DECISION' });
  });
  // Move forward to the saved stage if it is later than where replay stopped.
  if (s.stage === 'geography' && c.stage === 'founding') step({ type: 'ADVANCE' });
  if (s.stage === 'founded' && stageIndex(c.stage) > stageIndex('founded')) step({ type: 'ADVANCE' });
  if (s.stage === 'outcome' && stageIndex(c.stage) !== stageIndex('outcome')) step({ type: 'ADVANCE' });
  // Restore an unconfirmed selection for the current screen only.
  const key = s.stage === 'founding' ? 'founding' : s.stage === 'decision' ? s.currentDecision : null;
  if (key && typeof c.pending[key] === 'string') {
    const next = reduce(s, { type: 'SELECT', key, option: c.pending[key] });
    s = next;
  }
  s.drafts = { ...c.drafts };
  return s;
}
