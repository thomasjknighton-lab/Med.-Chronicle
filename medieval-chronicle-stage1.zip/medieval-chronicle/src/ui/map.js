// Lightweight SVG village map, drawn in code (no image files). Optional to explore.
import { h, s } from './dom.js';

const TREES = [[20, 20], [40, 12], [62, 24], [12, 50], [30, 200], [16, 230], [44, 252], [360, 120], [382, 140], [366, 170], [388, 196], [330, 250], [356, 262], [192, 18], [214, 30]];

function house(x, y, fresh) {
  return s('g', { class: 'm-house' },
    s('rect', { x, y: y + 6, width: 16, height: 10 }),
    s('path', { d: `M${x - 2},${y + 7} L${x + 8},${y} L${x + 18},${y + 7} Z`, class: fresh ? 'm-roof is-new' : 'm-roof' })
  );
}

function label(x, y, text, isNew, anchor) {
  return s('text', { x, y, 'text-anchor': anchor || null, class: isNew ? 'm-label is-new' : 'm-label' }, isNew ? `${text} (new)` : text);
}

export function drawMap(model, { onPick } = {}) {
  const g = model.geography;
  const f = model.flags;
  const pick = (id) => (e) => {
    e.stopPropagation();
    onPick?.(id);
  };
  const svg = s('svg', { viewBox: '0 0 400 280', class: `village-map geo-${g}`, 'aria-hidden': 'true', focusable: 'false' });
  svg.append(s('rect', { x: 0, y: 0, width: 400, height: 280, class: 'm-ground' }));

  // Geography
  if (g === 'river') {
    svg.append(s('path', { d: 'M0,236 C80,224 140,258 220,246 S330,222 400,232 L400,280 L0,280 Z', class: 'm-meadow' }));
    svg.append(s('path', { d: 'M0,250 C80,236 140,268 220,256 S330,232 400,244', class: 'm-river', onclick: pick('nature') }));
  } else if (g === 'coastal') {
    svg.append(s('path', { d: 'M300,280 C318,236 352,196 400,168 L400,280 Z', class: 'm-sea', onclick: pick('nature') }));
    svg.append(s('path', { d: 'M350,228 q6,-4 12,0 t12,0 M330,256 q6,-4 12,0 t12,0', class: 'm-wave' }));
    svg.append(s('path', { d: 'M368,206 l14,0 l-3,6 l-8,0 z M375,206 l0,-12 l7,9 z', class: 'm-boat' }));
  } else if (g === 'woodland') {
    for (const [x, y] of TREES) svg.append(s('circle', { cx: x, cy: y, r: 9, class: 'm-tree', onclick: pick('nature') }));
  } else if (g === 'upland') {
    svg.append(s('g', { class: 'm-hills', onclick: pick('nature') },
      s('path', { d: 'M0,40 C60,0 140,10 200,0' }),
      s('path', { d: 'M0,62 C70,22 150,30 240,12' }),
      s('path', { d: 'M260,280 C300,232 360,224 400,236' }),
      s('path', { d: 'M232,280 C280,216 350,204 400,212' })
    ));
  }

  // Road and hall
  svg.append(s('path', { d: 'M0,158 C120,150 200,120 260,104 S340,56 352,46', class: 'm-road', onclick: pick('road') }));
  if (f.has('dependable_landholder')) svg.append(s('path', { d: 'M150,140 C210,122 250,108 290,90 S340,60 350,50', class: 'm-ruts is-new' }));
  svg.append(s('g', { class: 'm-hall' }, s('rect', { x: 340, y: 22, width: 30, height: 18 }), s('path', { d: 'M336,23 L355,10 L374,23 Z' })));
  svg.append(label(394, 56, 'Landholder’s hall', false, 'end'));

  // Fields (strips)
  const fields = s('g', { class: 'm-fields', onclick: pick('fields') });
  fields.append(s('rect', { x: 34, y: 60, width: 130, height: 70, class: 'm-field' }));
  for (let x = 48; x < 164; x += 13) fields.append(s('line', { x1: x, y1: 60, x2: x, y2: 130, class: 'm-strip' }));
  svg.append(fields, label(70, 54, 'Fields'));

  // Church
  svg.append(s('g', { class: 'm-church', onclick: pick('church') },
    s('rect', { x: 240, y: 132, width: 30, height: 18 }),
    s('rect', { x: 270, y: 120, width: 10, height: 30 }),
    s('path', { d: 'M275,112 L275,120 M271,115 L279,115', class: 'm-cross' })
  ), label(236, 164, 'Church'));

  // Homes
  const fresh = f.has('upkeep_precedent');
  const homes = s('g', { onclick: pick('homes') });
  [[184, 168], [210, 180], [236, 176], [196, 200], [226, 206]].forEach(([x, y]) => homes.append(house(x, y, fresh)));
  svg.append(homes, label(200, 236, fresh ? 'Homes, re-thatched' : 'Homes', fresh));

  // Workshop
  svg.append(s('g', { class: 'm-workshop', onclick: pick('workshop') },
    s('rect', { x: 118, y: 178, width: 26, height: 16 }),
    s('path', { d: 'M115,179 L131,168 L147,179 Z' })
  ), label(112, 208, 'Workshop'));

  // Decision-driven features
  if (f.has('shared_reserves')) {
    svg.append(s('g', { class: 'm-store is-new', onclick: pick('store') },
      s('rect', { x: 278, y: 180, width: 26, height: 18 }),
      s('path', { d: 'M274,181 L291,170 L308,181 Z' })
    ), label(262, 212, 'Store', true));
  }
  if (f.has('cooperative_precedent')) {
    svg.append(s('circle', { cx: 162, cy: 222, r: 11, class: 'm-threshing is-new', onclick: pick('threshing') }), label(120, 246, 'Threshing floor', true));
  }
  return svg;
}

export function renderMapPanel(model, villageName, selectedId, onPick) {
  if (!model) return null;
  const selected = model.places.find((p) => p.id === selectedId);
  const anyNew = model.places.some((p) => p.isNew || p.changed);
  return h('section', { class: 'map-panel', 'aria-labelledby': 'map-title' },
    h('h2', { id: 'map-title', class: 'panel-title' }, `Map of ${villageName}`),
    h('figure', { class: 'map-figure' },
      drawMap(model, { onPick }),
      anyNew ? h('figcaption', null, 'Places marked “new” or drawn with dashed lines changed because of your choices.') : null
    ),
    h('p', { class: 'map-hint' }, 'Optional: choose a place to learn about it.'),
    h('ul', { class: 'place-list' },
      model.places.map((p) =>
        h('li', null, h('button', { type: 'button', class: 'place-btn', id: `place-${p.id}`, 'aria-pressed': p.id === selectedId ? 'true' : 'false', onclick: () => onPick(p.id) },
          p.name, p.isNew ? ' (new)' : p.changed ? ' (changed)' : ''))
      )
    ),
    selected ? h('div', { class: 'place-detail', role: 'status' }, h('strong', null, selected.name), h('p', null, selected.text)) : null
  );
}
