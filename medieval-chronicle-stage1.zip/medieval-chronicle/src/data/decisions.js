// Data-driven decision definitions. Tokens in {braces} are replaced with the student's names
// as plain text (never HTML). Stage 1 contains Decision 1 only; Stage 2 adds Decisions 2–9.
//
// Each option:
//   effects        resource deltas applied only after confirmation
//   flags          story flags (lowercase_with_underscores) used by later scenes and the map
//   relationships  narrative-only notes keyed by landholder | church | merchants | crown
//   preview        qualitative benefits and risks shown BEFORE confirmation (no numbers)
//   outcome        narrative, local legacy (simulation), and real-history note shown AFTER

export const DECISIONS = [
  {
    id: 'd1',
    number: 1,
    era: 'early',
    year: 'c. 920',
    title: 'Preparing for Winter',
    setup: [
      'The harvest is in. Before the dark months arrive, {village} must decide where its time and effort should go.',
      'The grain must last until spring. Several roofs leak. The local landholder expects the customary food render and the days of work owed for the land the families hold.'
    ],
    voices: [
      { who: 'farmer', text: 'If the stores run short in February, nothing else will matter.' },
      { who: 'craft', text: 'A barn with a rotten roof loses grain anyway. We should mend first.' },
      { who: 'priest', text: 'Keep faith with the landholder’s reeve, and perhaps he will keep faith with us.' }
    ],
    prompt: 'What should the village put first this winter?',
    options: [
      {
        id: 'A',
        label: 'Store extra grain',
        description: 'Set aside more of the harvest in a shared store for late winter.',
        preview: {
          benefits: 'A cushion if spring comes late or the next harvest is poor.',
          risks: 'Less grain left for trading, brewing, or other needs.'
        },
        effects: { food: 1 },
        flags: ['shared_reserves'],
        relationships: {},
        outcome: {
          narrative: [
            'Sacks and baskets fill a shared store near {farmer}’s house. Every household knows what is inside and who added what.',
            'In February, when other villages begin to ration, {village} still has grain to spare.'
          ],
          legacy: 'Keeping shared reserves becomes a habit in {village}, one that later generations remember.',
          history:
            'Most medieval villagers lived on what they grew. One bad harvest could mean hunger, so storing food was a serious decision.'
        }
      },
      {
        id: 'B',
        label: 'Repair buildings and tools',
        description: 'Mend roofs, fences, and the plough before the frosts.',
        preview: {
          benefits: 'Fewer breakdowns, and fewer quarrels over damage and blame.',
          risks: 'Time spent mending is time not spent storing food.'
        },
        effects: { stability: 1 },
        flags: ['upkeep_precedent'],
        relationships: {},
        outcome: {
          narrative: [
            '{craft} leads the repairs. By the first frost the roofs are freshly thatched and the plough is sound again.',
            'When a winter storm comes, the houses hold, and there is less to argue about.'
          ],
          legacy: 'Looking after shared buildings becomes something {village} expects of itself.',
          history:
            'Houses in tenth-century villages were usually timber-framed with thatched roofs. They needed constant repair to stay usable.'
        }
      },
      {
        id: 'C',
        label: 'Fulfill customary obligations first',
        description: 'Deliver the food render and labour owed to the landholder, on time and in full.',
        preview: {
          benefits: 'A dependable relationship with the local landholder.',
          risks: 'Little time or grain left over for the village’s own projects.'
        },
        effects: {},
        flags: ['dependable_landholder'],
        relationships: {
          landholder: 'The landholder’s reeve regards {village} as dependable. Whether that earns kindness later is uncertain.'
        },
        outcome: {
          narrative: [
            'Carts of grain, cheese, and ale go to the landholder’s hall on the agreed days. The reeve notes that {village} paid what was owed without delay.',
            '{farmer} grumbles that the village’s own roofs still leak.'
          ],
          legacy: '{village} gains a reputation for keeping its word with the landholder.',
          history:
            'Many communities in this period owed food renders and labour to landholders, based on local custom. These duties varied from place to place and were not the same as the later system of serfdom.'
        }
      },
      {
        id: 'D',
        label: 'Organize shared work',
        description: 'Families pool their labour: threshing together and repairing in turns.',
        preview: {
          benefits: 'Builds habits of working together and solving problems as a group.',
          risks: 'Families with more land or more hands may feel they are carrying others.'
        },
        effects: { stability: 1 },
        flags: ['cooperative_precedent'],
        relationships: {},
        outcome: {
          narrative: [
            'Families thresh grain together on a shared floor and take turns mending each other’s roofs.',
            'Not everyone gives the same amount, and {craft} complains about it, but the work gets done.'
          ],
          legacy: 'Shared work becomes part of how {village} solves problems.',
          history:
            'Medieval villagers often worked land in large shared fields and depended on neighbours for ploughing and harvest work.'
        }
      }
    ]
  }
];

export const TOTAL_DECISIONS = 9;

export function getDecision(id) {
  return DECISIONS.find((d) => d.id === id) || null;
}

export function getOption(decisionId, optionId) {
  const d = getDecision(decisionId);
  return d ? d.options.find((o) => o.id === optionId) || null : null;
}
