// Period-appropriate name suggestions (Old English forms). All village names are invented.
export const NAME_SUGGESTIONS = {
  village: ['Æscford', 'Brocwella', 'Wulfingtun', 'Stanburna', 'Eadwinesham', 'Thornwic'],
  farmer: ['Ælfwine', 'Eadgifu', 'Godwine', 'Wulfrun', 'Leofric', 'Ælfflæd'],
  craft: ['Osgar', 'Leofgifu', 'Wulfnoth', 'Eadwen', 'Cynric', 'Brihtgifu'],
  priest: ['Wulfgar', 'Ælfnoth', 'Eadwold', 'Beornstan', 'Cyneweard', 'Oswig']
};

export const NAME_FIELDS = [
  { key: 'village', label: 'Village name', hint: 'Old English place names often ended in -tun (farm), -ford (river crossing), or -leah (clearing).' },
  { key: 'farmer', label: 'Founding farmer', hint: 'Works the fields and keeps livestock.' },
  { key: 'craft', label: 'Founding craftworker or merchant', hint: 'Makes and trades goods: tools, cloth, pots, or salt.' },
  { key: 'priest', label: 'Founding priest', hint: 'Serves the village church and leads worship.' }
];

export const NAME_MIN = 1;
export const NAME_MAX = 30;

// Teachers can add words here. Matching is case-insensitive on whole words.
export const BLOCKED_WORDS = ['fuck', 'shit', 'bitch', 'cunt', 'dick', 'nigger', 'fag', 'slut', 'whore', 'penis', 'sex'];

const ALLOWED = /^[\p{L}\p{M}][\p{L}\p{M}'’ .-]*$/u;

/** Returns null if valid, otherwise a plain-language error message. */
export function validateName(raw) {
  if (typeof raw !== 'string') return 'Enter a name.';
  const value = raw.trim().replace(/\s+/g, ' ');
  if (value.length < NAME_MIN) return 'Enter a name.';
  if (value.length > NAME_MAX) return `Use ${NAME_MAX} characters or fewer.`;
  if (!ALLOWED.test(value)) return 'Use letters, spaces, hyphens, or apostrophes only.';
  const words = value.toLowerCase().split(/[\s'’.-]+/);
  if (words.some((w) => BLOCKED_WORDS.includes(w))) return 'Choose a different name.';
  return null;
}

export function cleanName(raw) {
  return String(raw).trim().replace(/\s+/g, ' ');
}
