// Builds the Village History Report with jsPDF. Pure with respect to the page: it takes a
// jsPDF constructor and state and returns a document, so it runs in the browser and in Node tests.
// Assessment comes first. Missing work is always labelled "Not completed", never faked.
import { GEOGRAPHIES } from '../data/geographies.js';
import { FOUNDING_PRIORITIES } from '../data/founding.js';
import { DECISIONS, TOTAL_DECISIONS, getOption } from '../data/decisions.js';
import { RESOURCE_INFO } from '../data/text.js';
import { RESOURCE_KEYS } from '../engine/resources.js';
import { fill } from '../engine/state.js';
import { completionSummary } from '../engine/progress.js';

const NOT_DONE = 'Not completed';
const CP1252_EXTRA = new Set('€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ');

/** Standard PDF fonts only cover Western European characters. Map others safely. */
export function toPdfText(input) {
  const s = String(input ?? '');
  let out = '';
  for (const ch of s) {
    const code = ch.codePointAt(0);
    if (ch === '\n' || (code >= 0x20 && code <= 0xff && !(code >= 0x7f && code < 0xa0)) || CP1252_EXTRA.has(ch)) {
      out += ch;
      continue;
    }
    const base = ch.normalize('NFD').replace(/\p{M}/gu, '');
    out += base && base.codePointAt(0) <= 0xff ? base : '?';
  }
  return out;
}

export function buildReport(JsPDF, state, { studentName = '', generatedAt = '' } = {}) {
  const doc = new JsPDF({ unit: 'pt', format: 'letter' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 56;
  const width = W - M * 2;
  let y = M;

  const ensure = (h) => {
    if (y + h > H - M) {
      doc.addPage();
      y = M;
    }
  };
  const text = (str, { size = 11, style = 'normal', gap = 4, indent = 0 } = {}) => {
    doc.setFont('helvetica', style);
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(toPdfText(str), width - indent);
    const lh = size * 1.35;
    for (const line of lines) {
      ensure(lh);
      doc.text(line, M + indent, y + size);
      y += lh;
    }
    y += gap;
  };
  const heading = (str, size = 15) => {
    ensure(size * 3);
    y += 6;
    text(str, { size, style: 'bold', gap: 2 });
    doc.setLineWidth(0.75);
    doc.line(M, y, M + width, y);
    y += 10;
  };
  const sub = (str) => text(str, { size: 11.5, style: 'bold', gap: 2 });
  const field = (label, value) => {
    ensure(48);
    sub(label);
    const has = typeof value === 'string' && value.trim();
    text(has ? value.trim() : NOT_DONE, { style: has ? 'normal' : 'italic', gap: 8 });
  };
  const newPage = () => {
    doc.addPage();
    y = M;
  };

  const names = state.names;
  const geo = state.geography ? GEOGRAPHIES[state.geography] : null;
  const founding = state.founding ? FOUNDING_PRIORITIES[state.founding] : null;
  const village = names?.village || 'Unnamed village';
  const summary = completionSummary(state);
  const d = state.drafts;

  // 1. Identification, status, historical argument
  text('The Medieval Chronicle', { size: 10, gap: 0 });
  text('Village History Report', { size: 22, style: 'bold', gap: 6 });
  text(`Student: ${studentName.trim() || '(not entered)'}`, { gap: 0 });
  text(`Village: ${village}`, { gap: 0 });
  text(`Report generated: ${generatedAt || 'date not recorded'}`, { gap: 0 });
  text(`Playthrough ID: ${state.playthroughId}`, { size: 9, gap: 8 });
  sub(`Status: ${summary.complete ? 'Complete' : 'Incomplete'}`);
  for (const i of summary.items) text(`${i.done >= i.total ? '[x]' : '[ ]'}  ${i.label}: ${i.done} of ${i.total}`, { gap: 0, indent: 10 });
  y += 8;

  heading('Historical Argument');
  field('Claim: What was the most important change in your village across the Middle Ages?', d['arg.claim']);
  field('Evidence: Two examples from the Village Chronicle and one documented event or source', d['arg.evidence']);
  field('Explanation: How does that evidence connect to broader developments in medieval England and Europe?', d['arg.explanation']);
  sub('Self-checklist');
  text(NOT_DONE, { style: 'italic' });

  // 2. Village profile
  newPage();
  heading('Village Profile (Simulation)');
  if (!geo) {
    text(NOT_DONE, { style: 'italic' });
  } else {
    text(`Geography: ${geo.name}, ${geo.region}. (Assigned at random.)`, { gap: 2 });
    text(`Founding priority: ${founding ? founding.name : NOT_DONE}`, { gap: 2 });
    if (names) text(`Founders: ${names.farmer} (farmer), ${names.craft} (craftworker), ${names.priest} (priest)`, { gap: 8 });
    sub('Resources (1 to 5)');
    const start = state.resourceHistory.find((r) => r.id === 'start')?.after;
    for (const k of RESOURCE_KEYS) {
      text(`${RESOURCE_INFO[k].name}: started at ${start ? start[k] : '?'}, now ${state.resources[k]}`, { gap: 0, indent: 10 });
    }
    y += 6;
    sub('Resource changes');
    for (const r of state.resourceHistory.filter((r) => r.id !== 'start')) {
      const parts = r.changes.length
        ? r.changes.map((c) => `${RESOURCE_INFO[c.key].name} ${c.before} to ${c.after}${c.capped ? ` (would have changed by ${c.requested >= 0 ? '+' : ''}${c.requested}, but resources stay between 1 and 5)` : ''}`)
        : ['no change to resources'];
      text(`${r.label}: ${parts.join('; ')}`, { gap: 2, indent: 10 });
    }
    y += 6;
    sub('Maps, c. 920 and c. 1400');
    text('Not available in this test build.', { style: 'italic' });
  }

  // 3. Decisions timeline
  newPage();
  heading('Decision Timeline (Simulation)');
  for (let n = 1; n <= TOTAL_DECISIONS; n++) {
    const def = DECISIONS.find((x) => x.number === n);
    const chosen = def && state.decisions[def.id];
    if (def && chosen) {
      const opt = getOption(def.id, chosen.option);
      sub(`Decision ${n}, ${def.year}: ${def.title}`);
      text(`Choice: ${opt.label}. ${opt.description}`, { gap: 2, indent: 10 });
      text(`Legacy: ${fill(opt.outcome.legacy, names)}`, { gap: 8, indent: 10 });
    } else {
      sub(`Decision ${n}${def ? `, ${def.year}: ${def.title}` : ''}`);
      text(NOT_DONE, { style: 'italic', indent: 10 });
    }
  }
  field('Justification for Decision 6', d['just.d6']);
  field('Justification for Decision 9', d['just.d9']);

  // 4. Sources and reflections
  newPage();
  heading('Source Observations (Real History)');
  ['Laws of King Æthelstan', 'Henry Knighton’s Chronicle', 'Great Horwood manor court: Alice Aboveton, 1318', 'The Anonimalle Chronicle, 1381'].forEach((t, i) =>
    field(`Source ${i + 1}: ${t}`, d[`obs.s${i + 1}`])
  );
  heading('Era Reflections');
  ['Chapter I: Early Middle Ages', 'Chapter II: High Middle Ages', 'Chapter III: Late Middle Ages'].forEach((t, i) => field(t, d[`refl.e${i + 1}`]));

  // 5. Epilogue
  newPage();
  heading('Epilogue and Turning Points (Simulation)');
  text(NOT_DONE, { style: 'italic' });

  // Footer on every page
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(toPdfText(`${village} — Village History Report — page ${p} of ${pages}`), M, H - 30);
  }
  return doc;
}

/** Safe ASCII slug for filenames; transliterates Old English letters. */
export function slug(name, fallback = 'village') {
  const v = String(name || fallback)
    .replace(/Æ/g, 'Ae').replace(/æ/g, 'ae').replace(/Þ/g, 'Th').replace(/þ/g, 'th').replace(/[Ðð]/g, 'd')
    .normalize('NFD')
    .replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase();
  return v || fallback;
}

export function reportFilename(state) {
  return `village-history-report-${slug(state.names?.village)}.pdf`;
}
